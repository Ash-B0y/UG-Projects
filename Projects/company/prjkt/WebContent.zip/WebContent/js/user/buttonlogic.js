
function goBack() {
    window.history.back();
}

function goForward() {
    window.history.forward();
}

